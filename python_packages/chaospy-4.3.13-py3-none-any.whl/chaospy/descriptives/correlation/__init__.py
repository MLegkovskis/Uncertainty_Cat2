"""Correlation operators."""
from .pearson import Corr
from .auto_correlation import Acf
from .spearman import Spearman
